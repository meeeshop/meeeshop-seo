if (!customElements.get('tpt-swiper-testimonial')) {
	customElements.define(
		'tpt-swiper-testimonial',
		class TptComingSoon extends HTMLElement {
			constructor() {
				super();

				const swiperThumbElement = this.querySelector('.swiper-thumb');
				const swiperMainElement = this.querySelector('.swiper-main');
				const pagination = this.querySelector('.swiper-pagination');

				var sliderThumb = new Swiper(swiperThumbElement, {
					loop: false,
					centeredSlides: true,
					slidesPerView: 5,
					spaceBetween: 0,
					initialSlide: 2,
					breakpoints: {
						0: {
							slidesPerView: 3,
						},
						768: {
							slidesPerView: 3,
						},
						1024: {
							slidesPerView: 5,
						},
					},
				});

				var sliderMain = new Swiper(swiperMainElement, {
					spaceBetween: 30,
					slidesPerView: 1,
					watchSlidesProgress: true,
					effect: 'fade',
					initialSlide: 2,
					// autoplay: {
					// 	delay: 2500,
					// 	disableOnInteraction: true,
					// },
					loop: false,
					thumbs: {
						swiper: sliderThumb,
					},
					pagination: {
						el: pagination,
						clickable: true,
						renderBullet: function (index, className) {
							return '<span class="' + className + '">' + (index + 1) + '</span>';
						},
					},
				});

				sliderMain.on('slideChangeTransitionStart', function () {
					sliderThumb.slideTo(sliderMain.activeIndex);
				});
			}
		}
	);
}
